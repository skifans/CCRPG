"""
to download cx_Freeze. First download python 3.4.2 - 64 bit
https://www.python.org/downloads/release/python-342/
Must be placed in defult location
Download cx_Freeze from;
https://pypi.python.org/pypi?:action=display&name=cx_Freeze&version=4.3.4
(file cx_Freeze-4.3.4.win-amd64-py3.4.exe (md5))
Run .exe, do not change ANYTHING!
Go to C:\Python34
Search for cx
To folders and 4 files should appear
Copy the folders to location of portable python 3.2/App/Lib/site-packages
Now copy 3 of the files (NOT cx_Freeze-wininst.log) to portable python 3.2/App/Scripts
Open portable python 3.2
To check install use import cx_Freeze
To run open cmd, using cd/dir brows to C:\python43.
Type the command python.exe (full path to where this file is saved, must be called setup.py) build
"""


import cx_Freeze

executables = [cx_Freeze.Executable("Shop.py")] #name of file to make .exe, to be saved in same location as this

#name = name of .exe
cx_Freeze.setup(
    name="maps",
    executables = executables
    )